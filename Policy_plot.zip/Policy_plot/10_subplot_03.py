import pandas as pd
import matplotlib.pyplot as plt

my_dataset = pd.read_excel(
    'Start research.xlsx', sheet_name='Sheet1')

fig = plt.figure()

ax1 = fig.add_subplot(2, 2, 1)
ax1.scatter(my_dataset.Year, my_dataset.Population, marker='x', label="cross")
ax1.set_xlabel("Population[ppm]")
ax1.set_ylabel("Year")
ax1.set_xlim([100, 1000])
ax1.set_ylim([0, 100])
ax1.legend()
'''
ax2 = fig.add_subplot(2, 2, 2)
ax2.scatter(my_dataset.Zr, my_dataset.Th, marker='o', label="circle")
ax2.set_xlabel("Zr [ppm]")
ax2.set_ylabel("Th [ppm]")
ax2.set_xlim([100, 1000])
ax2.set_ylim([0, 100])
ax2.legend()

ax3 = fig.add_subplot(2, 2, 3)
ax3.scatter(my_dataset.Zr, my_dataset.Th, marker='^', label="triangle")
ax3.set_xlabel("Zr [ppm]")
ax3.set_ylabel("Th [ppm]")
ax3.set_xlim([100, 1000])
ax3.set_ylim([0, 100])
ax3.legend()

ax4 = fig.add_subplot(2, 2, 4)
ax4.scatter(my_dataset.Zr, my_dataset.Th, marker='d', label="diamond")
ax4.set_xlabel("Zr [ppm]")
ax4.set_ylabel("Th [ppm]")
ax4.set_xlim([100, 1000])
ax4.set_ylim([0, 100])
ax4.legend()
'''
fig.tight_layout()
plt.show()
